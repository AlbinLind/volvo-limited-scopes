"""Volvo coordinators."""

from abc import abstractmethod
import asyncio
from collections.abc import Callable, Coroutine
from dataclasses import dataclass
from datetime import timedelta
import logging
from typing import Any, cast, override

from volvocarsapi.api import VolvoCarsApi
from volvocarsapi.models import (
    VolvoApiException,
    VolvoAuthException,
    VolvoCarsApiBaseModel,
    VolvoCarsValue,
    VolvoCarsValueStatusField,
    VolvoCarsVehicle,
)

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import ConfigEntryAuthFailed, ConfigEntryNotReady
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .const import DATA_BATTERY_CAPACITY, DOMAIN

VERY_SLOW_INTERVAL = 30
SLOW_INTERVAL = 15
MEDIUM_INTERVAL = 2
FAST_INTERVAL = 1

_LOGGER = logging.getLogger(__name__)


@dataclass
class VolvoContext:
    """Volvo context."""

    api: VolvoCarsApi
    vehicle: VolvoCarsVehicle
    supported_commands: list[str]


@dataclass
class VolvoRuntimeData:
    """Volvo runtime data."""

    fast_coordinator: VolvoFastIntervalCoordinator
    medium_coordinator: VolvoMediumIntervalCoordinator
    slow_coordinator: VolvoSlowIntervalCoordinator
    very_slow_coordinator: VolvoVerySlowIntervalCoordinator
    context: VolvoContext

    @property
    def interval_coordinators(self) -> tuple[VolvoBaseCoordinator, ...]:
        """Return all coordinators."""
        return (
            self.fast_coordinator,
            self.medium_coordinator,
            self.slow_coordinator,
            self.very_slow_coordinator,
        )


type VolvoConfigEntry = ConfigEntry[VolvoRuntimeData]
type CoordinatorData = dict[str, VolvoCarsApiBaseModel | None]


def schedule_location_update(coordinator: VolvoBaseCoordinator) -> None:
    """Schedule a location-only update."""
    coordinator.config_entry.runtime_data.slow_coordinator.async_schedule_location_update()


def _is_invalid_api_field(field: VolvoCarsApiBaseModel | None) -> bool:
    if not field:
        return True

    if isinstance(field, VolvoCarsValueStatusField) and field.status == "ERROR":
        return True

    return False


class VolvoBaseCoordinator(DataUpdateCoordinator[CoordinatorData]):
    """Volvo base interval coordinator."""

    config_entry: VolvoConfigEntry

    def __init__(
        self,
        hass: HomeAssistant,
        entry: VolvoConfigEntry,
        context: VolvoContext,
        update_interval: timedelta,
        name: str,
    ) -> None:
        """Initialize the coordinator."""

        super().__init__(
            hass,
            _LOGGER,
            config_entry=entry,
            name=name,
            update_interval=update_interval,
        )

        self._api_calls: list[Callable[[], Coroutine[Any, Any, Any]]] = []
        self.context = context

    @override
    async def _async_setup(self) -> None:
        try:
            self._api_calls = await self._async_determine_api_calls()
        except VolvoAuthException as err:
            raise ConfigEntryAuthFailed(
                translation_domain=DOMAIN,
                translation_key="unauthorized",
                translation_placeholders={"message": err.message},
            ) from err
        except VolvoApiException as err:
            raise ConfigEntryNotReady from err

        if not self._api_calls:
            self.update_interval = None

    @override
    async def _async_update_data(self) -> CoordinatorData:
        """Fetch data from API."""

        data: CoordinatorData = {}

        if not self._api_calls:
            return data

        valid = False
        exception: Exception | None = None

        results = await asyncio.gather(
            *(call() for call in self._api_calls), return_exceptions=True
        )

        for result in results:
            if isinstance(result, VolvoAuthException):
                # If one result is a VolvoAuthException, then probably all requests
                # will fail. In this case we can cancel everything to
                # reauthenticate.
                #
                # Raising ConfigEntryAuthFailed will cancel future updates
                # and start a config flow with SOURCE_REAUTH (async_step_reauth)
                _LOGGER.debug(
                    "%s - Authentication failed. %s",
                    self.config_entry.entry_id,
                    result.message,
                )
                raise ConfigEntryAuthFailed(
                    translation_domain=DOMAIN,
                    translation_key="unauthorized",
                    translation_placeholders={"message": result.message},
                ) from result

            if isinstance(result, VolvoApiException):
                # Maybe it's just one call that fails. Log the error and
                # continue processing the other calls.
                _LOGGER.debug(
                    "%s - Error during data update: %s",
                    self.config_entry.entry_id,
                    result.message,
                )
                exception = exception or result
                continue

            if isinstance(result, Exception):
                # Something bad happened, raise immediately.
                raise UpdateFailed(
                    translation_domain=DOMAIN,
                    translation_key="update_failed",
                ) from result

            api_data = cast(CoordinatorData, result)
            data |= {
                key: field
                for key, field in api_data.items()
                if not _is_invalid_api_field(field)
            }

            valid = True

        # Raise an error if not a single API call succeeded
        if not valid:
            raise UpdateFailed(
                translation_domain=DOMAIN,
                translation_key="update_failed",
            ) from exception

        return data

    def get_api_field(self, api_field: str | None) -> VolvoCarsApiBaseModel | None:
        """Get the API field based on the entity description."""

        return self.data.get(api_field) if self.data and api_field else None

    @abstractmethod
    async def _async_determine_api_calls(
        self,
    ) -> list[Callable[[], Coroutine[Any, Any, Any]]]:
        """Determine which API calls to make for this coordinator."""


class VolvoVerySlowIntervalCoordinator(VolvoBaseCoordinator):
    """Volvo coordinator with very slow update rate."""

    def __init__(
        self,
        hass: HomeAssistant,
        entry: VolvoConfigEntry,
        context: VolvoContext,
    ) -> None:
        """Initialize the coordinator."""

        super().__init__(
            hass,
            entry,
            context,
            timedelta(minutes=VERY_SLOW_INTERVAL),
            "Volvo very slow interval coordinator",
        )

    @override
    async def _async_determine_api_calls(
        self,
    ) -> list[Callable[[], Coroutine[Any, Any, Any]]]:
        api = self.context.api

        return [
            api.async_get_command_accessibility,
            api.async_get_diagnostics,
            api.async_get_tyre_states,
            api.async_get_warnings,
        ]

    @override
    async def _async_update_data(self) -> CoordinatorData:
        data = await super()._async_update_data()

        # Add static values
        if self.context.vehicle.has_battery_engine():
            data[DATA_BATTERY_CAPACITY] = VolvoCarsValue.from_dict(
                {
                    "value": self.context.vehicle.battery_capacity_kwh,
                }
            )

        return data


class VolvoSlowIntervalCoordinator(VolvoBaseCoordinator):
    """Volvo coordinator with slow update rate."""

    def __init__(
        self,
        hass: HomeAssistant,
        entry: VolvoConfigEntry,
        context: VolvoContext,
    ) -> None:
        """Initialize the coordinator."""

        super().__init__(
            hass,
            entry,
            context,
            timedelta(minutes=SLOW_INTERVAL),
            "Volvo slow interval coordinator",
        )

        self._location_supported = False
        self._location_update_task: asyncio.Task[None] | None = None

    def async_schedule_location_update(self) -> None:
        """Schedule a single location update if none is in-flight."""
        if not self._location_supported:
            return

        if self._location_update_task and not self._location_update_task.done():
            return

        self._location_update_task = self.config_entry.async_create_background_task(
            self.hass,
            self._async_update_location(),
            "Volvo location update",
        )

    @override
    async def _async_determine_api_calls(
        self,
    ) -> list[Callable[[], Coroutine[Any, Any, Any]]]:
        api = self.context.api
        api_calls: list[Any] = [
            api.async_get_brakes_status,
            api.async_get_engine_warnings,
            api.async_get_odometer,
        ]

        # Volvo is returning FORBIDDEN for the location request in case the vehicle
        # is in an unsupported region. Since we can't know where the vehicle is
        # located, we silently ignore the failure. If (re-)authentication is needed,
        # other requests will fail as well and trigger the re-auth flow.
        location = None
        try:
            location = await api.async_get_location()
        except VolvoAuthException as ex:
            _LOGGER.debug(
                "%s - Location not supported for this vehicle. %s",
                self.config_entry.entry_id,
                ex.message,
            )

        if location and location.get("location") is not None:
            api_calls.append(api.async_get_location)
            self._location_supported = True

        return api_calls

    async def _async_update_location(self) -> None:
        """Fetch only the location data and update listeners."""
        if not self._location_supported:
            return

        try:
            location = await self.context.api.async_get_location()
        except (VolvoApiException, VolvoAuthException) as ex:
            _LOGGER.debug(
                "%s - Location update failed: %s",
                self.config_entry.entry_id,
                ex.message,
            )
            return

        valid_location: dict[str, VolvoCarsApiBaseModel | None] = {
            key: field
            for key, field in location.items()
            if not _is_invalid_api_field(field)
        }

        if valid_location:
            self.data = dict(self.data or {}) | valid_location
            self.async_update_listeners()


class VolvoMediumIntervalCoordinator(VolvoBaseCoordinator):
    """Volvo coordinator with medium update rate."""

    def __init__(
        self,
        hass: HomeAssistant,
        entry: VolvoConfigEntry,
        context: VolvoContext,
    ) -> None:
        """Initialize the coordinator."""

        super().__init__(
            hass,
            entry,
            context,
            timedelta(minutes=MEDIUM_INTERVAL),
            "Volvo medium interval coordinator",
        )

        self._supported_capabilities: list[str] = []

    @override
    async def _async_update_data(self) -> CoordinatorData:
        """Fetch data and trigger location update on engine-off."""
        previous_state = self.get_api_field("engineStatus")
        data = await super()._async_update_data()
        new_state = data.get("engineStatus")

        if (
            isinstance(previous_state, VolvoCarsValue)
            and previous_state.value == "RUNNING"
            and isinstance(new_state, VolvoCarsValue)
            and new_state.value
            and new_state.value != "RUNNING"
        ):
            schedule_location_update(self)

        return data

    @override
    async def _async_determine_api_calls(
        self,
    ) -> list[Callable[[], Coroutine[Any, Any, Any]]]:
        api = self.context.api
        vehicle = self.context.vehicle
        api_calls: list[Any] = [
            api.async_get_engine_status,
            api.async_get_statistics,
        ]

        if vehicle.has_battery_engine():
            capabilities = await api.async_get_energy_capabilities()

            if capabilities.get("isSupported", False):

                def _normalize_key(key: str) -> str:
                    return "chargingStatus" if key == "chargingSystemStatus" else key

                self._supported_capabilities = [
                    _normalize_key(key)
                    for key, value in capabilities.items()
                    if isinstance(value, dict) and value.get("isSupported", False)
                ]

                api_calls.append(self._async_get_energy_state)

        if self.context.vehicle.has_combustion_engine():
            api_calls.append(api.async_get_fuel_status)

        return api_calls

    async def _async_get_energy_state(
        self,
    ) -> dict[str, VolvoCarsValueStatusField | None]:
        def _mark_ok(
            field: VolvoCarsValueStatusField | None,
        ) -> VolvoCarsValueStatusField | None:
            if field:
                field.status = "OK"

            return field

        energy_state = await self.context.api.async_get_energy_state()

        return {
            key: _mark_ok(value)
            for key, value in energy_state.items()
            if key in self._supported_capabilities
        }


class VolvoFastIntervalCoordinator(VolvoBaseCoordinator):
    """Volvo coordinator with fast update rate."""

    def __init__(
        self,
        hass: HomeAssistant,
        entry: VolvoConfigEntry,
        context: VolvoContext,
    ) -> None:
        """Initialize the coordinator."""

        super().__init__(
            hass,
            entry,
            context,
            timedelta(minutes=FAST_INTERVAL),
            "Volvo fast interval coordinator",
        )

    @override
    async def _async_determine_api_calls(
        self,
    ) -> list[Callable[[], Coroutine[Any, Any, Any]]]:
        api = self.context.api

        return [
            api.async_get_doors_status,
            api.async_get_window_states,
        ]

    @override
    async def _async_update_data(self) -> CoordinatorData:
        """Fetch data and trigger location update on lock."""
        previous_state = self.get_api_field("centralLock")
        data = await super()._async_update_data()
        new_state = data.get("centralLock")

        if (
            isinstance(previous_state, VolvoCarsValue)
            and previous_state.value != "LOCKED"
            and isinstance(new_state, VolvoCarsValue)
            and new_state.value == "LOCKED"
        ):
            schedule_location_update(self)

        return data
